function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2289, 4)
end
