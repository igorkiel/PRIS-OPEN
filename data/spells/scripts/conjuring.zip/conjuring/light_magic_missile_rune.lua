function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2287, 10)
end
