
function onCastSpell(creature, variant)
	return creature:conjureItem(0, 28140, 100, CONST_ME_MAGIC_BLUE)
end