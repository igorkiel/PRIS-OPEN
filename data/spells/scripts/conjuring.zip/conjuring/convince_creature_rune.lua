function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2290, 1)
end
