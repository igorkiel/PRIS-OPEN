function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 19392, 10)
end
