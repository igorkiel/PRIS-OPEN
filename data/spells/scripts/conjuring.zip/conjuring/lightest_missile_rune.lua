function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 23723, 10)
end
