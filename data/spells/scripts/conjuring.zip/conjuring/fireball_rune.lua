function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2302, 5)
end
