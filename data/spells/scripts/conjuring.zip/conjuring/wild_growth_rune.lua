function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2269, 2)
end
