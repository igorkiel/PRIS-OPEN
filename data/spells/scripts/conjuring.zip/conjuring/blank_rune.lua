function onCastSpell(creature, variant)
	return creature:conjureItem(0, 2260, 1)
end
