function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2274, 4)
end
