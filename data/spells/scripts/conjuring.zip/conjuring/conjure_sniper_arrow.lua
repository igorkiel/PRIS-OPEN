function onCastSpell(creature, variant)
	return creature:conjureItem(0, 7364, 5, CONST_ME_MAGIC_BLUE)
end
