
function onCastSpell(creature, variant)
	return creature:conjureItem(0, 27641, 25, CONST_ME_MAGIC_BLUE)
end
