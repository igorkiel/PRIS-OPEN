function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2311, 10)
end
