function onCastSpell(creature, variant)
	return creature:conjureItem(2260, 2295, 5)
end
