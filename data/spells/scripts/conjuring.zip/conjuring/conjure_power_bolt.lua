function onCastSpell(creature, variant)
	return creature:conjureItem(0, 2547, 10, CONST_ME_MAGIC_BLUE)
end
